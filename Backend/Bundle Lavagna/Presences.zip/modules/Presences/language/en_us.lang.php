<?php
/*+*************************************************************************************
 * The contents of this file are subject to the VTECRM License Agreement
 * ("licenza.txt"); You may not use this file except in compliance with the License
 * The Original Code is: VTECRM
 * The Initial Developer of the Original Code is VTECRM LTD.
 * Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
 * All Rights Reserved.
 ***************************************************************************************/

$mod_strings = Array(
	'Presences' => 'Presences',
	'SINGLE_Presences' => 'Presence',

	'LBL_PRESENCES_INFORMATION' => 'Presences Information',
	'LBL_CUSTOM_INFORMATION' => 'Custom Information',
	'LBL_DESCRIPTION_INFORMATION' => 'Description Information',

	'Card Id' => 'Card Id / Temporary PIN',
	'Presence Date' => 'Presence Date',
	'Employee' => 'Employee',
	'Total Hours' => 'Total Hours',
);
